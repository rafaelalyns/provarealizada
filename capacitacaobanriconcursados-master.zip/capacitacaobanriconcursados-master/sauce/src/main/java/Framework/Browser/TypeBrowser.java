package Framework.Browser;

public enum TypeBrowser {

    CHROME, 
    FIREFOX, 
    EDGE,
    HEADLESS;
}
